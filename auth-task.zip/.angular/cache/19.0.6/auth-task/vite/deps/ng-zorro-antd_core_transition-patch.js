import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-B25ECA33.js";
import "./chunk-OGOOUMV7.js";
import "./chunk-D6A7BPUU.js";
import "./chunk-HPDQVLCV.js";
import "./chunk-I2SI46AA.js";
import "./chunk-EIB7IA3J.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
