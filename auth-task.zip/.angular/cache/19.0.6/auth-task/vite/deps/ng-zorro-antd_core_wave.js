import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-EGDBXXZX.js";
import "./chunk-TE4VAORJ.js";
import "./chunk-QIPBRRD3.js";
import "./chunk-32TI4LNT.js";
import "./chunk-J3LVLDJS.js";
import "./chunk-CDH3F5VA.js";
import "./chunk-D6ZOUBMM.js";
import "./chunk-SB3PADO7.js";
import "./chunk-OGOOUMV7.js";
import "./chunk-D6A7BPUU.js";
import "./chunk-HPDQVLCV.js";
import "./chunk-I2SI46AA.js";
import "./chunk-EIB7IA3J.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
