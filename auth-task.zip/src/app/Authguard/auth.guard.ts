import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (route, state) => {
    const router = inject(Router);
    const userthere = localStorage.getItem('LoggedUser');
    if (!userthere) {
        return router.parseUrl('/login');
    }
    return true;
};
