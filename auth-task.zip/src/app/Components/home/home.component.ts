import { CommonModule } from '@angular/common';
// import { jsDocComment } from '@angular/compiler';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
// import * as CryptoJS from 'crypto-js';
import { NzButtonComponent } from 'ng-zorro-antd/button';

@Component({
  selector: 'app-home',
  imports: [CommonModule, NzButtonComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})

export class HomeComponent {
  loggedUser: any;
  constructor(private router: Router) {
    const jwt = localStorage.getItem('JwtToken');
    const userthere = localStorage.getItem('LoggedUser');
    // const userthere = JSON.parse(user);
    if (userthere != null) {
      // if(jwt != null) {
      // let DecryptJwt = CryptoJS.AES.decrypt(jwt.trim()).toString(CryptoJS.enc.Utf8);
      this.loggedUser = JSON.parse(userthere);
    }
  }

  logout() {
    localStorage.removeItem('LoggedUser');
    localStorage.removeItem('JwtToken');
    this.router.navigateByUrl('/login');
  }
}
