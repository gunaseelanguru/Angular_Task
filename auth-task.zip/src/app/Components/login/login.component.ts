import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import * as CryptoJS from 'crypto-js';

import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink, Router } from '@angular/router';
import { NzAlertModule } from 'ng-zorro-antd/alert';

import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, NzButtonModule, NzCheckboxModule, NzFormModule, NzInputModule, CommonModule, RouterLink, NzAlertModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})

export class LoginComponent implements OnInit {
  validateForm!: FormGroup;

  constructor(private fb: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      email: [null, [Validators.required, Validators.email]],
      password: [null, [Validators.required]]
    });
  }

  submitForm(): void {
    if (this.validateForm.valid) {
      const UsersList = localStorage.getItem('users_list');
      if (UsersList != null) {
        const users = JSON.parse(UsersList);
        const isUserPresent = users.find((user: any) => user.email == this.validateForm.value.email && user.password == this.validateForm.value.password);
        if (isUserPresent != undefined) {
          // alert("User Found...");
          let jwt_token = CryptoJS.AES.encrypt(isUserPresent.name, isUserPresent.email).toString();
          localStorage.setItem('JwtToken', jwt_token);
          localStorage.setItem('LoggedUser', JSON.stringify(isUserPresent));
          this.router.navigateByUrl('/home');
        } else {
          alert("No User Found")
        }
      } else {
        alert("No User Found")
      }
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
}











